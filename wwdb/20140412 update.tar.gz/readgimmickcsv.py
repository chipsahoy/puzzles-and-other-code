from optparse import OptionParser

#parse commandline input
parser = OptionParser()
parser.add_option("-i", dest="inputfile", type="string", help="input csv file")
parser.add_option("-o", dest="outputdir", type="string", help="Output SQL file")

(options,args) = parser.parse_args()

#open inputs and output
input = open(options.inputfile, "r")
output = open(options.outputdir, "a")

inputlines = input.readlines()

gimmicks = []
#add basic structure(Games, Posters, Teams)
for line in inputlines:
	line = line.replace("'", "''")
	line = line.strip()
	line = line.split("\t")
	print line
	if "Original Account" in line[0]:
		continue
	if line[1] in gimmicks:
		continue
	gimmicks.append(line[1])
	output.write("insert into Gimmick(posteridmain, posteridgimmick) values ((SELECT posterid FROM Poster WHERE UPPER(postername) = UPPER('" + line[0] + "') and forumid=1), (SELECT posterid FROM Poster WHERE UPPER(postername) = UPPER('" + line[1] + "') and forumid=1));\n")
