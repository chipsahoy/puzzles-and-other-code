from optparse import OptionParser
 
#parse commandline input
parser = OptionParser()
parser.add_option("-i", dest="inputfile", type="string", help="input csv file")
parser.add_option("-o", dest="outputdir", type="string", help="Output SQL file")
 
 
(options,args) = parser.parse_args()
 
#open inputs and output
input = open(options.inputfile, "r")
output = open(options.outputdir, "w")
 
inputlines = input.readlines()

Games = []
Teams = []
Players = []
globalThreadID = 0

output.write("use dev;\n")
output.write("truncate GameRole;\ntruncate Player;\ntruncate Role;\ntruncate Team;\ntruncate Game;\n")

#add basic structure(Games, Players, Teams)
for line in inputlines:
    threadid = None
    
    line = line.replace("'", "''") # mysql escape character
    #line = line.strip()
    line = line.split("\t")
    if len(line) < 3 or "Game Name" in line[0] or line[6] == "" or int(line[11]) == 0:
    	# potential source for bug if 'game name' finds itself into the text somewhere -iver
        continue
    if line[4][len(line[4]) - 1] == " ":
        line[4] = line[4][0:len(line[4]) - 1]
    if line[5][len(line[5]) - 1] == " ":
        line[5] = line[5][0:len(line[5]) - 1]
    if len(line) > 12 and line[12] != "" and line[12][len(line[12]) - 1] == " ":
        line[12] = line[12][0:len(line[12]) - 1]
    if line[7] == "":
        line[7] = "Vanilla"
    forumid = 1 if "twoplustwo" in line[1] else 2 # match forumid, since they there might be multiple players with the same playername
	

    if line[0] not in Games:
        mods = line[4].split("/")
        mod = mods[0]
        date = line[2].split("/")
        #print date
        #print line[1]
        if "forumserver.twoplustwo.com" in line[1]:
            subforumname = line[1].split("/")[4]
            threadid = line[1].split("-")[len(line[1].split("-")) - 1]
            while(threadid[len(threadid) - 1] == "/" or threadid[len(threadid) - 1] == " "):
                threadid = threadid[:-1]
            subforumid = line[1].split("/")[3]
            output.write("INSERT IGNORE INTO SubForum (subforumid, subforumname, forumid) VALUES (" + subforumid + ", '" + subforumname + "', 1);\n")
        elif "archives1.twoplustwo.com" in line[1]:
            subforumname = "archives"
            threadlist = line[1].split("&")
            for item in threadlist:
                if "Number" in item:
                    threadid = item.split("=")[1]
        elif "usgamers.net" in line[1]:
            subforumname = "usgamers"
            threadid = line[1].split("=")[len(line[1].split("=")) - 1]
        elif "pokernet.dk" in line[1]:
            subforumname = "PokerNet.dk"
            globalThreadID = globalThreadID + 1
            threadid = str(globalThreadID)
        elif "werewolfhideout" in line[1]:
            subforumname = "werewolfhideout"
            globalThreadID = globalThreadID + 1
            threadid = str(globalThreadID)
            
        if threadid is None:
            globalThreadID = globalThreadID + 1
            threadid = str(globalThreadID)
        #print threadid
        Games.append(line[0])
        output.write("insert ignore into Thread (threadid, url, subforumid) values (" + threadid + ", '" + line[1] + "', (SELECT subforumid FROM SubForum WHERE subforumname = '" + subforumname + "'));\n")
        output.write("insert into Game (gamename,startdate,gametype,modid, threadid, gamelength, subforumid) values ('" + line[0] + "','20" + date[2] + "-" + date[0] + "-" + date[1] + "','" + line[3] + "', (SELECT posterid FROM Poster WHERE UPPER(postername) = UPPER('" + mod + "') and forumid=" + str(forumid) + "), " + threadid + ", " + line[10] + ", (SELECT subforumid FROM SubForum WHERE subforumname = '" + subforumname + "'));\n")

#    found = False
    
    if line[0] + "," + line[6].lower() in Teams:
#       found = True
		if line[9] == '0': 
			line[9] = 1
		elif line[9] == '1': 
			line[9] = 0
		if 'c' in line[8]:
			deathtype = "Conceded"
		elif 's' in line[8]:
			if line[6] == "Wolves" and line[9] == 0:
				deathtype = "Conceded"
			elif line[6] == "Village" and line[9] == 0:
				deathtype = "Eaten"
			else:
				deathtype = "Survived"
		elif 'n' in line[8]:
			deathtype = "Night Killed"
		elif 'l' in line[8]:
			deathtype = "Lynched"
		elif 'm' in line[8]:
			deathtype = "Mod Killed"
		elif 'd' in line[8]:
			deathtype = "Day Killed"
		if deathtype == "Conceded" or deathtype == "Eaten":
			deathday = line[10]
			#print line[0]
		elif len(line[8]) > 1:
				deathday = line[8][1:]
		else:
			deathday = 'null'
		output.write("INSERT IGNORE INTO Role (rolename) VALUES ('" + line[7] + "');\n")
		output.write("INSERT IGNORE INTO DeathType (deathtypename) VALUES ('" + deathtype + "');\n")
		output.write("insert into GameRole (teamid, deathtypeid, deathday, roletypeid) values((SELECT teamid FROM Team WHERE affiliationid = (SELECT affiliationid FROM Affiliation WHERE affiliationname = '" + line[6] + "') AND threadid = (SELECT threadid FROM Game WHERE gamename = '" + line[0] + "')),(SELECT deathtypeid FROM DeathType WHERE deathtypename = '" + deathtype + "')," + deathday + ",(SELECT roleid FROM Role WHERE rolename = '" + line[7] + "'));\n")
		output.write("insert into Player (roleid, posterid, startday, forumid) VALUES ((SELECT MAX(roleid) from GameRole),(SELECT posterid FROM Poster WHERE UPPER(postername) = UPPER('" + line[5] + "') and forumid=" + str(forumid) + "),0, " + str(forumid) + ");\n")
    
    else:
        Teams.append(line[0] + "," + line[6].lower())
        if line[9] == '0': 
            line[9] = 1
        elif line[9] == '1': 
            line[9] = 0
        #print line[9]
        output.write("INSERT IGNORE INTO Affiliation (affiliationname) VALUES ('" + line[6] + "');\n")
        output.write("insert into Team (affiliationid, affiliationnumber, victory, threadid) values((SELECT affiliationid FROM Affiliation WHERE affiliationname = '" +  line[6] +"'), (SELECT count(*) FROM Team as t2 WHERE t2.affiliationid=(SELECT affiliationid FROM Affiliation WHERE affiliationname = '" +  line[6] +"') AND t2.threadid=(SELECT threadid FROM Game WHERE gamename = '" + line[0] + "')), " + str(line[9]) + ", (SELECT threadid FROM Game WHERE gamename = '" + line[0] + "'));\n")
        if 'c' in line[8]:
            deathtype = "Conceded"
        elif 's' in line[8]:
            if line[6] == "Wolves" and line[9] == 0:
                deathtype = "Conceded"
            elif line[6] == "Village" and line[9] == 0:
                deathtype = "Eaten"
            else:
                deathtype = "Survived"
        elif 'n' in line[8]:
            deathtype = "Night Killed"
        elif 'l' in line[8]:
            deathtype = "Lynched"
        elif 'm' in line[8]:
            deathtype = "Mod Killed"
        elif 'd' in line[8]:
            deathtype = "Day Killed"
        if deathtype == "Conceded" or deathtype == "Eaten":
            deathday = line[10]
            #print line[0]
        elif len(line[8]) > 1:
                deathday = line[8][1:]
        else:
            deathday = 'null'
        output.write("INSERT IGNORE INTO Role (rolename) VALUES ('" + line[7] + "');\n")
        output.write("INSERT IGNORE INTO DeathType (deathtypename) VALUES ('" + deathtype + "');\n")
        output.write("insert into GameRole (teamid, deathtypeid, deathday, roletypeid) values((SELECT teamid FROM Team WHERE affiliationid = (SELECT affiliationid FROM Affiliation WHERE affiliationname = '" + line[6] + "') AND threadid = (SELECT threadid FROM Game WHERE gamename = '" + line[0] + "')),(SELECT deathtypeid FROM DeathType WHERE deathtypename = '" + deathtype + "')," + deathday + ",(SELECT roleid FROM Role WHERE rolename = '" + line[7] + "'));\n")
        output.write("insert into Player (roleid, posterid, startday, forumid) VALUES ((SELECT MAX(roleid) from GameRole),(SELECT posterid FROM Poster WHERE UPPER(postername) = UPPER('" + line[5] + "') and forumid=" + str(forumid) + "),0, " + str(forumid) + ");\n")
    
    if line[12].strip() != '':
		# get rid of quotes (when there are multiple subs per slot
		line[12] = line[12].replace('"', '').strip()
		line[13] = line[13].replace('"', '').strip()
		subs = line[12].split(',')
		subday = line[13].split(',')
		lastplayer = line[5]
		if(len(subs) != len(subday)):
			print "subday != numsubs"
		
		for i in range(0,len(subs)):
			output.write("UPDATE Player SET startday = " + subday[i] + " WHERE roleid=(SELECT MAX(roleid) from GameRole) AND posterid=(SELECT posterid FROM Poster WHERE UPPER(postername) = UPPER('" + lastplayer + "') and forumid=" + str(forumid) + ");\n")
			output.write("insert into Player (roleid, posterid, startday, forumid) VALUES ((SELECT MAX(roleid) from GameRole),(SELECT posterid FROM Poster WHERE UPPER(postername) = UPPER('" + subs[i] + "') and forumid=" + str(forumid) + "),0, " + str(forumid) + ");\n")
			output.write("UPDATE Player SET endday = " + subday[i] + " WHERE roleid=(SELECT MAX(roleid) from GameRole) AND posterid=(SELECT posterid FROM Poster WHERE UPPER(postername) = UPPER('" + subs[i] + "') and forumid=" + str(forumid) + ");\n")
			lastplayer = subs[i]
		output.write("UPDATE Player SET startday = 0 WHERE roleid=(SELECT MAX(roleid) from GameRole) AND posterid=(SELECT posterid FROM Poster WHERE UPPER(postername) = UPPER('" + subs[i] + "') and forumid=" + str(forumid) + ");\n")
	
    
output.write("UPDATE Game as g, Team as t, GameRole as gr SET gr.deathday = g.gamelength WHERE g.threadid = t.threadid AND t.teamid = gr.teamid AND (gr.deathtypeid IN (SELECT deathtypeid FROM DeathType WHERE deathtypename = 'Eaten' OR deathtypename = 'Survived' OR deathtypename = 'Conceded'));\n")







#    subs = 0
#    while len(line) > 12+2*subs and len(line[12 +2*subs]) > 1:
#        if subs == 0:
#             lastplayer = 5
#         else:
#             lastplayer = 12+2*(subs-1)
#         #print lastplayer, subs, 12+2*subs, 13+2*subs, line[12+2*subs], line[13+2*subs]
#         output.write("insert into Player (roleid, posterid, startday) VALUES ((SELECT MAX(roleid) from GameRole),(SELECT posterid FROM Poster WHERE UPPER(postername) = UPPER('" + line[12+2*subs] + "')),0);\n")
#         output.write("UPDATE Player SET startday = " + line[13+2*subs] + " WHERE roleid=(SELECT MAX(roleid) from GameRole) AND posterid=(SELECT posterid FROM Poster WHERE UPPER(postername) = UPPER('" + line[lastplayer] + "'));\n")
#         output.write("UPDATE Player SET endday = " + line[13+2*subs] + " WHERE roleid=(SELECT MAX(roleid) from GameRole) AND posterid=(SELECT posterid FROM Poster WHERE UPPER(postername) = UPPER('" + line[12+2*subs] + "'));\n")
#         subs+=1
	# subs
#	if line[0] == 'Average Speed Non-Star Werewolf II':
#	if line[0] == 'Werewolf 1':
#		print len(line)
#		print line[12]

